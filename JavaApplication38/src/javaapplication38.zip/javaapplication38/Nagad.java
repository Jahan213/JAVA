
package javaapplication38;

public class Nagad extends OnlineBanking{
    @Override
     public float cashOutCharge(){
        return 9.00f;
    }
    
}
