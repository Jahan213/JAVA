
package javaapplication38;

public class JavaApplication38 {
   
    public static void main(String[] args) {
        Bkash b = new Bkash();
    Nagad n = new Nagad();
    Rocket r = new Rocket();
    
    System.out.println(b.cashOutCharge());
    System.out.println(n.cashOutCharge());
    System.out.println(r.cashOutCharge());
                              
    }
    
}
