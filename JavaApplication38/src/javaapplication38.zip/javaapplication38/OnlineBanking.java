
package javaapplication38;

public class OnlineBanking {private float balance;
   
    public float cashOutCharge(){
        return 10.00f;
    }
    
    public float geBalance(){
        return balance;
    }
    
    public void setBalance(float balance){
        this.balance = balance;
    }
    
}
