
package javaapplication38;

public class Rocket extends OnlineBanking {
    @Override
    public float cashOutCharge(){
        return 16.75f;
    }
    
    
}
